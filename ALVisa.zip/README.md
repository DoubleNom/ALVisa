Firefox extension for AL\
Monitor new available appointment for a VISA application

This is for personnal use only

Requirements in option:
* Provide email + password credential 
* Provide refresh rate in minutes (default 60)
* Provide email that will receive notification emails
