console.log("Groups -> Schedule")
var button = document.getElementsByClassName("button primary small")[1]
setTimeout(function () {
    button.click()
}, 500)